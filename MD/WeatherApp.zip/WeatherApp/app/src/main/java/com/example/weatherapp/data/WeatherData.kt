package com.example.weatherapp.data

data class WeatherData(
    val city: String
)
